import { useEffect, useState } from "react"
import { getDoctorList } from "../services/api"
import { Doctor } from "../types/Doctor"
import { DoctorListItem } from "./DoctorListItem"

export const DoctorList = () => {
    const [doctorItems, setDoctorItems] = useState<Doctor[]>([])
    useEffect(() => {
        getDoctorList().then((doctors) => {
            setDoctorItems(doctors)
        })
    }, [])

    return (
        <div className="flex flex-col gap-y-4 h-1/2 overflow-auto min-h-60 w-2/3 mx-auto min-w-[600px] max-w-[800px] p-4">
            {doctorItems.map((item) => <DoctorListItem key={item.id} item={item} />)}
        </div>
    )
}