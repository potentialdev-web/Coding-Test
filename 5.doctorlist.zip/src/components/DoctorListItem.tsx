import React from "react"
import { Doctor } from "../types/Doctor"

interface DoctorListItemProps {
    item: Doctor;
}

export const DoctorListItem: React.FC<DoctorListItemProps> = ({
    item
}) => {
    return (
        <div className="flex bg-white rounded-xl items-center px-4 py-2 gap-x-4 cursor-pointer hover:bg-gray-50">
            <div className="flex items-center w-1/2 gap-x-4">
                <img className="rounded-full w-12 h-12" src={item.photo} alt={item.fullname} />
                <div className="flex flex-col font-bold">
                    <span>{item.fullname}</span>
                    <span>{item.clinic}</span>
                </div>
            </div>

            <div className="flex flex-col text-sm w-1/2">
                <span>Phone: &nbsp;&nbsp;{item.phone}</span>
                <span>Gender: {item.gender}</span>
                <span>Email: &nbsp;&nbsp;&nbsp;{item.email}</span>
            </div>
        </div>
    )
}