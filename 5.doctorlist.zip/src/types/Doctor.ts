export interface Doctor {
    id: number;
    photo: string;
    clinic: string;
    gender: "male" | "female";
    phone: string;
    fullname: string;
    email: string;
}