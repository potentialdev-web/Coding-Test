import { DoctorList } from './components/DoctorList'

function App() {

  return (
    <div className='bg-gray-200 h-screen'>
      <h1 className='font-bold text-center text-black text-lg py-2'>Doctor's list</h1>
      <DoctorList />
    </div>
  )
}

export default App
