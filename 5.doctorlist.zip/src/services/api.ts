import { Doctor } from "../types/Doctor";

const API_URL = import.meta.env.VITE_API_URL;

export const getDoctorList = () => new Promise<Doctor[]>((resolve, reject) => {
    fetch(API_URL).then(data =>
        data.ok ? data.json() : new Error())
        .then(data => resolve(data))
        .catch(() => reject())
})