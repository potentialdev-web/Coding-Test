package main

import (
	"fmt"
)

func mostCommonChars(s string) map[rune]struct{} {
	frequency := make(map[rune]int)
	result := make(map[rune]struct{})
	maxFreq := 0

	for _, char := range s {
		frequency[char]++
		if frequency[char] > maxFreq {
			maxFreq = frequency[char]
		}
	}

	for char, freq := range frequency {
		if freq == maxFreq {
			result[char] = struct{}{}
		}
	}

	return result
}

func main() {
	fmt.Println("Most common characters in 'annoying':")
	printSet(mostCommonChars("annoying"))

	fmt.Println("Most common characters in 'implementation':")
	printSet(mostCommonChars("implementation"))
}

func printSet(set map[rune]struct{}) {
	for char := range set {
		fmt.Printf("%c ", char)
	}
	fmt.Println()
}
