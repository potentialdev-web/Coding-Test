package main

import (
	"reflect"
	"testing"
)

func makeSet(chars []rune) map[rune]struct{} {
	set := make(map[rune]struct{})
	for _, char := range chars {
		set[char] = struct{}{}
	}
	return set
}

func TestMostCommonChars(t *testing.T) {
	tests := []struct {
		input    string
		expected []rune
	}{
		{"annoying", []rune{'n'}},
		{"implementation", []rune{'i', 'm', 'e', 't', 'n'}},
		{"aabbcc", []rune{'a', 'b', 'c'}},
		{"abc", []rune{'a', 'b', 'c'}},
		{"", []rune{}},
	}

	for _, test := range tests {
		got := mostCommonChars(test.input)
		want := makeSet(test.expected)

		if !reflect.DeepEqual(got, want) {
			t.Errorf("mostCommonChars(%q) = %v; want %v", test.input, got, want)
		}
	}
}
