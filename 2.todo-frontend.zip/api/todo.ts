import { BASE_URL } from '@/constants/api';
import axios from 'axios';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { Todo } from '@/constants/types';

const TODO_BASE = `${BASE_URL}/todos`;

export const initializeAuth = async (success: () => void, failed: () => void) => {
    try {
        const token = await AsyncStorage.getItem('token');
        setToken(token)
        success()
    } catch (e) {
        failed()
    }
}

export const setToken = (token: string | null) => {
    if (token) {
        axios.defaults.headers.common['Authorization'] = token;
        AsyncStorage.setItem('token', token);
    } else {
        delete axios.defaults.headers.common['Authorization'];
        AsyncStorage.removeItem('token')
    }
}

export const fetchTodos = () => axios.get(`${TODO_BASE}`);
export const addTodo = (todo: Todo) => axios.post(`${TODO_BASE}`, todo);
export const updateTodo = (todo: Todo) => axios.put(`${TODO_BASE}/${todo.id}`, todo);
export const deleteTodo = (todo: Todo) => axios.delete(`${TODO_BASE}/${todo.id}`);