import { BASE_URL } from '@/constants/api';
import { User } from '@/constants/types';
import axios from 'axios';

export const login = (data: User) => axios.post(`${BASE_URL}/login`, data);
export const register = (data: User) => axios.post(`${BASE_URL}/register`, data);
export const getUsername = () => axios.get(`${BASE_URL}/users/current`);
