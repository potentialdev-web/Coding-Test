import { getUsername } from "@/api/auth";
import { addTodo, deleteTodo, fetchTodos, initializeAuth, setToken } from "@/api/todo";
import { TodoItem } from "@/components/TodoItem";
import { globalStyles, todoStyles } from "@/constants/styles";
import { Todo } from "@/constants/types";
import { useRouter } from "expo-router";
import { useEffect, useMemo, useState } from "react";
import { Dimensions, Text, TouchableOpacity, View, TextInput, ScrollView } from "react-native";
import tw from 'twrnc'

const TodoListScreen = () => {
    const [todos, setTodos] = useState<Todo[]>([]);
    const [username, setUsername] = useState<string>("");

    const [title, setTitle] = useState<string>("");
    const [titleMsg, setTitleMsg] = useState<string>("");

    const activeTodos = useMemo(() => todos.filter(todo => !todo.done), [todos]);
    const doneTodos = useMemo(() => todos.filter(todo => todo.done), [todos]);

    const router = useRouter()

    const validateTitle = (text: string) => {
        const title = text.trim()
        setTitle(title)
        if (!title) {
            setTitleMsg("Todo title is required")
            return false;
        } else {
            setTitleMsg("");
            return true;
        }
    }

    const updateTodo = (todo: Todo) => {
        const index = todos.findIndex(item => item.id === todo.id);
        if (index !== -1) {
            const updatedTodos = todos.map((item, i) => (i === index ? todo : item));
            setTodos(updatedTodos);
        }
    }

    const onDeleteTodo = (todo: Todo) => {
        deleteTodo(todo).then(() => {
            const newTodos = todos.filter(item => todo.id != item.id);
            setTodos(newTodos)
        }).catch()
    }

    const logout = () => {
        setToken(null)
        router.push('/')
    }

    const submit = () => {
        if (validateTitle(title)) {
            addTodo({ title }).then((data) => {
                setTitle("")
                setTodos([...todos, data.data])
            }).catch(() => {

            })
        }
    }

    useEffect(() => {
        initializeAuth(() => {
            fetchTodos().then((result) => {
                console.log(result)
                setTodos(result.data)
            }).catch(e => {

            })

            getUsername().then(data => setUsername(data.data.username))
                .catch(() => { })
        },
            () => {
                router.push('/')
            })
    }, []);

    const { width } = Dimensions.get("window");
    const isSmallScreen = width < 640;

    return (
        <ScrollView style={tw``}>
            <View style={tw`flex flex-row bg-blue-300 py-2 mb-4 fixed top-0 items-center justify-between px-6`}>
                <Text style={globalStyles.WELCOME}>Welcome {username}</Text>
                <TouchableOpacity onPress={logout}>
                    <Text style={globalStyles.BUTTON}>Log Out</Text>
                </TouchableOpacity>
            </View>
            <View style={tw`flex ${isSmallScreen ? "flex-col" : "flex-row"} mx-auto gap-x-10`}>
                <View style={todoStyles.TODO}>
                    <Text style={todoStyles.TITLE}>To-Do</Text>
                    <ScrollView style={tw`my-4 max-h-[400px]`}>
                        <View style={tw`flex flex-col gap-y-2`}>
                            {activeTodos.map(todo => <TodoItem key={todo.id} todo={todo} update={updateTodo} deleteTodo={onDeleteTodo} />)}
                        </View>
                    </ScrollView>

                    <View style={globalStyles.TODO_INPUT}>
                        <Text style={globalStyles.LABEL}>Todo Title</Text>
                        <TextInput style={globalStyles.TEXT_INPUT} inputMode="text" value={title} onChangeText={(text) => validateTitle(text)} />
                        {titleMsg && <Text style={globalStyles.ERROR_LABEL}>{titleMsg}</Text>}
                        <TouchableOpacity onPress={submit}>
                            <Text style={globalStyles.BUTTON}>Add Todo</Text>
                        </TouchableOpacity>
                    </View>
                </View>
                <View style={todoStyles.DONE}>
                    <Text style={todoStyles.TITLE}>Done</Text>
                    <ScrollView style={tw`my-4 max-h-[400px]`}>
                        <View style={tw`flex flex-col gap-y-2`}>
                            {doneTodos.map(todo => <TodoItem key={todo.id} todo={todo} update={updateTodo} deleteTodo={onDeleteTodo} />)}
                        </View>
                    </ScrollView>
                </View>
            </View>
        </ScrollView>
    )
}

export default TodoListScreen;