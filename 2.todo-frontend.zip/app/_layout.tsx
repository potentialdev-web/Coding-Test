import { useFonts } from 'expo-font';
import { Stack } from 'expo-router';
import * as SplashScreen from 'expo-splash-screen';
import { useEffect } from 'react';
import 'react-native-reanimated';
import tw from 'twrnc'

SplashScreen.preventAutoHideAsync();

export default function RootLayout() {
  const [loaded] = useFonts({
    UbuntuRegular: require('../assets/fonts/Ubuntu-Regular.ttf'),
    UbuntuMediumItalic: require('../assets/fonts/Ubuntu-MediumItalic.ttf'),
    UbuntuMedium: require('../assets/fonts/Ubuntu-Medium.ttf'),
    UbuntuLightItalic: require('../assets/fonts/Ubuntu-LightItalic.ttf'),
    UbuntuLight: require('../assets/fonts/Ubuntu-Light.ttf'),
    UbuntuItalic: require('../assets/fonts/Ubuntu-Italic.ttf'),
    UbuntuBoldItalic: require('../assets/fonts/Ubuntu-BoldItalic.ttf'),
    UbuntuBold: require('../assets/fonts/Ubuntu-Bold.ttf'),
  });

  useEffect(() => {
    if (loaded) {
      SplashScreen.hideAsync();
    }
  }, [loaded]);

  if (!loaded) {
    return null;
  }

  return (
    <Stack screenOptions={{ headerShown: false }} />
  );
}
