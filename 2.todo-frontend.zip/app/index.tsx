import { login, register } from "@/api/auth";
import { setToken } from "@/api/todo";
import { globalStyles } from "@/constants/styles";
import { AxiosError } from "axios";
import { useRouter } from "expo-router";
import { useState } from "react";
import { TextInput, View, Text, TouchableOpacity, } from "react-native";
import tw from 'twrnc'

const AuthScreen = () => {
    const [username, setUsername] = useState<string>("");
    const [password, setPassword] = useState<string>("");
    const [usernameMsg, setUsernameMsg] = useState<string>("");
    const [passwordMsg, setPasswordMsg] = useState<string>("");

    const [errorMsg, setErrorMsg] = useState<string>("");
    const [infoMsg, setInfoMsg] = useState<string>("");

    const router = useRouter();

    const validateUsername = (text: string) => {
        const username = text.trim();
        setUsername(text)
        if (!username) {
            setUsernameMsg("Email is required");
            return false;
        } else if (/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(username)) {
            setUsernameMsg("");
            return true;
        } else {
            setUsernameMsg("Enter valid email address");
            return false;
        }
    }

    const validatePassword = (text: string) => {
        const password = text.trim();
        setPassword(text)
        if (!password) {
            setPasswordMsg("Password is required")
            return false;
        } else if (password.length > 6) {
            setPasswordMsg("");
            return true;
        } else {
            setPasswordMsg("Password should exceed 6 characters");
            return false;
        }
    }

    const submit = (isRegister: boolean) => {
        if (validateUsername(username) && validatePassword(password)) {
            setErrorMsg("");
            setInfoMsg("");
            const user = {
                username, password
            }
            if (isRegister) {
                register(user).then(() => {
                    setInfoMsg("Account Created")
                }).catch((e: AxiosError) => {
                    switch (e.response?.status) {
                        case 400:
                            setErrorMsg("Invalid Informations")
                            break;
                        case 409:
                            setErrorMsg("Email Already Exists")
                            break;
                        case 500:
                            setErrorMsg("Internal Server Error")
                            break;
                        default:
                            setErrorMsg("Network Error")
                    }
                })
            } else {
                login(user).then(result => {
                    setToken(`Bearer ${result.data.token}`)
                    router.push('/todos')
                }).catch((e: AxiosError) => {
                    switch (e.response?.status) {
                        case 400:
                            setErrorMsg("Invalid Informations")
                            break;
                        case 401:
                            setErrorMsg("Password Incorrect")
                            break;
                        case 404:
                            setErrorMsg("Email Not Found")
                            break;
                        case 500:
                            setErrorMsg("Internal Server Error")
                            break;
                        default:
                            setErrorMsg("Network Error")
                    }
                })
            }
        }
    }

    return (
        <View style={tw`max-w-[400px] min-w-[300px] mx-auto flex flex-col gap-y-4 bg-white p-6 rounded-xl mt-20 shadow-md`}>
            <Text style={globalStyles.WELCOME}>Welcome to Todo</Text>
            {errorMsg && <Text style={globalStyles.ERROR_NOTIFICATION}>{errorMsg}</Text>}
            {infoMsg && <Text style={globalStyles.INFO_NOTIFICATION}>{infoMsg}</Text>}
            <View style={globalStyles.FORM_INPUT}>
                <Text style={globalStyles.LABEL}>Email</Text>
                <TextInput style={globalStyles.TEXT_INPUT} inputMode="email" value={username} onChangeText={(text) => validateUsername(text)} />
                {usernameMsg && <Text style={globalStyles.ERROR_LABEL}>{usernameMsg}</Text>}
            </View>
            <View style={globalStyles.FORM_INPUT}>
                <Text style={globalStyles.LABEL}>Password</Text>
                <TextInput style={globalStyles.TEXT_INPUT} inputMode="none" value={password} onChangeText={(text) => validatePassword(text)} />
                {passwordMsg && <Text style={globalStyles.ERROR_LABEL}>{passwordMsg}</Text>}
            </View>

            <View style={tw`flex flex-row justify-between`}>
                <TouchableOpacity onPress={() => submit(false)}>
                    <Text style={globalStyles.BUTTON}>Sign In</Text>
                </TouchableOpacity>
                <TouchableOpacity onPress={() => submit(true)}>
                    <Text style={globalStyles.BUTTON}>Sign Up</Text>
                </TouchableOpacity>
            </View>
        </View>

    )
}

export default AuthScreen;