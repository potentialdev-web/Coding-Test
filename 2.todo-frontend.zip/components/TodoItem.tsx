import { updateTodo } from "@/api/todo"
import { globalStyles, todoStyles } from "@/constants/styles"
import { Todo } from "@/constants/types"
import { FC, useState } from "react"
import { TextInput, TouchableOpacity } from "react-native"
import { Pressable, Switch, Text, View } from "react-native"
import Icon from 'react-native-vector-icons/FontAwesome'
import tw from 'twrnc'

interface TodoItemProps {
    todo: Todo,
    update: (todo: Todo) => void,
    deleteTodo: (todo: Todo) => void
}

export const TodoItem: FC<TodoItemProps> = ({ todo, update, deleteTodo }) => {
    const [editing, setEditing] = useState<boolean>(false);
    const [title, setTitle] = useState<string>(todo.title);
    const [titleMsg, setTitleMsg] = useState<string>("");

    const toggleSwitch = () => {
        const newTodo = todo;
        newTodo.done = !todo.done;
        updateTodo(newTodo).then(() => update(newTodo)).catch()
    }

    const validateTitle = (text: string) => {
        const title = text.trim()
        setTitle(title)
        if (!title) {
            setTitleMsg("Todo title is required")
            return false;
        } else {
            setTitleMsg("");
            return true;
        }
    }

    const submit = () => {
        if (validateTitle(title)) {
            setEditing(false);
            const newTodo = todo;
            newTodo.title = title;
            updateTodo(newTodo).then(() => update(newTodo)).catch()
        }
    }

    function truncateText(text: string, maxLength: number) {
        return text.length > maxLength ? text.slice(0, maxLength) + '...' : text;
    }
    return (
        editing ?
            <View style={globalStyles.TODO_INPUT}>
                <Text style={globalStyles.LABEL}>Todo Title</Text>
                <TextInput style={globalStyles.TEXT_INPUT} inputMode="text" value={title} onChangeText={(text) => validateTitle(text)} />
                {titleMsg && <Text style={globalStyles.ERROR_LABEL}>{titleMsg}</Text>}
                <TouchableOpacity onPress={submit}>
                    <Text style={globalStyles.BUTTON_GREEN}>Update Todo</Text>
                </TouchableOpacity>
            </View> : <TouchableOpacity style={todoStyles.container} onPress={toggleSwitch}>
                <Text style={todo.done ? todoStyles.ITALIC : todoStyles.TITLE}>{truncateText(todo.title, 12)}</Text>
                <View style={tw`flex flex-row items-center gap-x-4`}>
                    <TouchableOpacity onPress={() => setEditing(true)}>
                        <Icon name="pencil" size={24} color="#FBBF24" />
                    </TouchableOpacity>
                    <TouchableOpacity onPress={() => deleteTodo(todo)}>
                        <Icon name="trash" size={24} color="#F87171" />
                    </TouchableOpacity>
                </View>
            </TouchableOpacity>
    )
}