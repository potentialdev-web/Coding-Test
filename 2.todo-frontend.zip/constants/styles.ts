import { Dimensions, StyleSheet } from "react-native";
import tw from 'twrnc'

export const fonts = StyleSheet.create({
    UbuntuRegular: {
        fontFamily: 'UbuntuRegular'
    },
    UbuntuMediumItalic: {
        fontFamily: 'UbuntuMediumItalic'
    },
    UbuntuMedium: {
        fontFamily: 'UbuntuMedium'
    },
    UbuntuLightItalic: {
        fontFamily: 'UbuntuLightItalic'
    },
    UbuntuLight: {
        fontFamily: 'UbuntuLight'
    },
    UbuntuItalic: {
        fontFamily: 'UbuntuItalic'
    },
    UbuntuBoldItalic: {
        fontFamily: 'UbuntuBoldItalic'
    },
    UbuntuBold: {
        fontFamily: 'UbuntuBold'
    },
});

export const globalStyles = {
    WELCOME: [
        fonts.UbuntuBold, tw`text-xl text-center`
    ],
    FORM_INPUT: [
        tw`flex flex-col gap-y-2`
    ],
    TODO_INPUT: [
        tw`flex flex-col gap-y-2 bg-white p-4 rounded-md`
    ],
    TEXT_INPUT: [
        tw`font-UbuntuRegular bg-white border border-blue-400 outline-none px-4 py-2 rounded-md focus:border-blue-600 text-lg`, fonts.UbuntuRegular
    ],
    LABEL: [
        fonts.UbuntuMedium, tw`text-md`
    ],
    BUTTON: [
        fonts.UbuntuMedium, tw`px-6 py-3 text-md bg-blue-400 rounded-md block text-white text-center`
    ],
    BUTTON_GREEN: [
        fonts.UbuntuMedium, tw`px-6 py-3 text-md bg-green-400 rounded-md block text-white text-center`
    ],
    ERROR_LABEL: [
        fonts.UbuntuMedium, tw`text-red-400`,
    ],
    ERROR_NOTIFICATION: [
        fonts.UbuntuMedium, tw`block px-6 py-3 bg-red-200 text-red-600 rounded-md text-md text-center`
    ],
    INFO_NOTIFICATION: [
        fonts.UbuntuMedium, tw`block px-6 py-3 bg-green-200 text-green-600 rounded-md text-md text-center`
    ],
}

const { width } = Dimensions.get("window");
const isSmallScreen = width < 640;

export const todoStyles = {
    container: tw`block px-6 py-3 rounded-md bg-white flex flex-row justify-between hover:bg-gray-100 items-center`,
    TODO: tw`p-6 bg-blue-200 ${isSmallScreen ? "w-full" : "w-1/2"} rounded-lg min-w-[300px] max-w-[400px] h-max shadow-md`,
    DONE: tw`p-6 bg-green-200 ${isSmallScreen ? "w-full" : "w-1/2"} rounded-lg min-w-[300px] max-w-[400px] h-max shadow-md`,
    TITLE: [
        fonts.UbuntuMedium, tw`text-black text-lg`,
    ],
    ITALIC: [
        fonts.UbuntuMediumItalic, tw`text-black text-lg`,
    ]
}