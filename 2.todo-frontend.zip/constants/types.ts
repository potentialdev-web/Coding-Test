export interface User {
    id?: string;
    username: string;
    password: string;
}

export interface Todo {
    id?: string;
    title: string;
    done?: boolean;
}