package database

import (
	"database/sql"
	"log"
	"todo-app/config"

	_ "github.com/mattn/go-sqlite3"
)

var DB *sql.DB

func InitDB() {
	var err error
	DB, err = sql.Open("sqlite3", config.AppConfig.DatabaseURL)
	if err != nil {
		log.Fatal(err)
	}

	// Create tables if they don't exist
	createTables()
}

func createTables() {
	createUsersTable := `CREATE TABLE IF NOT EXISTS users (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        username TEXT NOT NULL UNIQUE,
        password TEXT NOT NULL
    );`

	createTodosTable := `CREATE TABLE IF NOT EXISTS todos (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER,
        title TEXT NOT NULL,
        done BOOLEAN NOT NULL,
        FOREIGN KEY(user_id) REFERENCES users(id)
    );`

	if _, err := DB.Exec(createUsersTable); err != nil {
		log.Fatal(err)
	}
	if _, err := DB.Exec(createTodosTable); err != nil {
		log.Fatal(err)
	}
}
