package handler

import (
	"encoding/json"
	"net/http"
	"strconv"
	"todo-app/database"
	"todo-app/models"

	"github.com/gorilla/mux"
)

func CreateTodoHandler(w http.ResponseWriter, r *http.Request) {
	var todo models.Todo
	if err := json.NewDecoder(r.Body).Decode(&todo); err != nil {
		http.Error(w, "Invalid input", http.StatusBadRequest)
		return
	}

	userID := r.Context().Value("userID").(int)
	result, err := database.DB.Exec("INSERT INTO todos (user_id, title, done) VALUES (?, ?, ?)", userID, todo.Title, false)

	id, _ := result.LastInsertId()
	todo.ID = int(id)
	todo.Done = false
	todo.UserID = userID

	if err != nil {
		http.Error(w, "Error creating todo", http.StatusInternalServerError)
		return
	}

	json.NewEncoder(w).Encode(todo)
}

func GetTodosHandler(w http.ResponseWriter, r *http.Request) {
	userID := r.Context().Value("userID").(int)

	rows, err := database.DB.Query("SELECT id, title, done FROM todos WHERE user_id = ?", userID)
	if err != nil {
		http.Error(w, "Error fetching todos", http.StatusInternalServerError)
		return
	}
	defer rows.Close()

	todos := []models.Todo{}
	for rows.Next() {
		var todo models.Todo
		if err := rows.Scan(&todo.ID, &todo.Title, &todo.Done); err != nil {
			http.Error(w, "Error scanning todo", http.StatusInternalServerError)
			return
		}
		todo.UserID = userID
		todos = append(todos, todo)
	}

	json.NewEncoder(w).Encode(todos)
}

func UpdateTodoHandler(w http.ResponseWriter, r *http.Request) {
	var todo models.Todo
	if err := json.NewDecoder(r.Body).Decode(&todo); err != nil {
		http.Error(w, "Invalid input", http.StatusBadRequest)
		return
	}

	userID := r.Context().Value("userID").(int)
	_, err := database.DB.Exec("UPDATE todos SET title = ?, done = ? WHERE id = ? AND user_id = ?", todo.Title, todo.Done, todo.ID, userID)
	if err != nil {
		http.Error(w, "Error updating todo", http.StatusInternalServerError)
		return
	}

	w.WriteHeader(http.StatusNoContent)
}

func DeleteTodoHandler(w http.ResponseWriter, r *http.Request) {
	vars := mux.Vars(r)
	id, err := strconv.Atoi(vars["id"])
	if err != nil {
		http.Error(w, "Invalid todo ID", http.StatusBadRequest)
		return
	}

	userID := r.Context().Value("userID").(int)
	_, err = database.DB.Exec("DELETE FROM todos WHERE id = ? AND user_id = ?", id, userID)
	if err != nil {
		http.Error(w, "Error deleting todo", http.StatusInternalServerError)
		return
	}

	w.WriteHeader(http.StatusNoContent)
}
