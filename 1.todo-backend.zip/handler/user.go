package handler

import (
	"encoding/json"
	"net/http"
	"todo-app/database"
)

func GetCurrentUserHandler(w http.ResponseWriter, r *http.Request) {
	userID := r.Context().Value("userID").(int)
	row := database.DB.QueryRow("SELECT username FROM users WHERE id = ?", userID)
	var username string
	err := row.Scan(&username)

	if err != nil {
		http.Error(w, "Invalid username or password", http.StatusNotFound)
		return
	}

	json.NewEncoder(w).Encode(map[string]string{"username": username})
}
