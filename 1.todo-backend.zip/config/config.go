package config

import (
	"os"

	"github.com/joho/godotenv"
)

type Config struct {
	Port        string
	SecretKey   string
	DatabaseURL string
}

var AppConfig Config

func LoadConfig() {
	err := godotenv.Load()
	if err != nil {
		panic("Error loading .env file")
	}

	AppConfig = Config{
		Port:        getEnv("PORT", "8080"),
		SecretKey:   getEnv("SECRET_KEY", "your-secret-key"),
		DatabaseURL: getEnv("DATABASE_URL", "todo.db"),
	}
}

func getEnv(key, defaultVal string) string {
	if value, exists := os.LookupEnv(key); exists {
		return value
	}
	return defaultVal
}
