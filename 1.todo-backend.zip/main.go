package main

import (
	"net/http"
	"todo-app/config"
	"todo-app/database"
	"todo-app/handler"
	"todo-app/middleware"

	"github.com/gorilla/handlers"
	"github.com/gorilla/mux"
)

func main() {
	// Load configuration
	config.LoadConfig()

	// Initialize database
	database.InitDB()

	// Create a new router
	r := mux.NewRouter()

	// Authentication routes
	r.HandleFunc("/register", handler.RegisterHandler).Methods("POST")
	r.HandleFunc("/login", handler.LoginHandler).Methods("POST")

	userRouter := r.PathPrefix("/users").Subrouter()
	userRouter.Use(middleware.JWTMiddleware)
	userRouter.HandleFunc("/current", handler.GetCurrentUserHandler).Methods("GET")

	// Todo routes with JWT middleware
	todosRouter := r.PathPrefix("/todos").Subrouter()
	todosRouter.Use(middleware.JWTMiddleware)
	todosRouter.HandleFunc("", handler.CreateTodoHandler).Methods("POST")
	todosRouter.HandleFunc("", handler.GetTodosHandler).Methods("GET")
	todosRouter.HandleFunc("/{id:[0-9]+}", handler.UpdateTodoHandler).Methods("PUT")
	todosRouter.HandleFunc("/{id:[0-9]+}", handler.DeleteTodoHandler).Methods("DELETE")

	corsHandler := handlers.CORS(
		handlers.AllowedOrigins([]string{"*"}),
		handlers.AllowedMethods([]string{"GET", "POST", "PUT", "DELETE", "OPTIONS"}),
		handlers.AllowedHeaders([]string{"Content-Type", "Authorization"}),
	)(r)

	// Start server
	http.ListenAndServe(":"+config.AppConfig.Port, corsHandler)
}
